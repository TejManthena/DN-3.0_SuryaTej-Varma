package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    // Example method to demonstrate the repository
    public void displayRepositoryInfo() {
        System.out.println("BookRepository is working");
    }
}

